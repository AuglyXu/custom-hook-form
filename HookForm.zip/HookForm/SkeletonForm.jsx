import React from 'react';
import classnames from 'classnames';
import styles from './SkeletonForm.module.less';

const arr = [0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 1, 1, 1, 1];

function SkeletonForm(props) {
    const { mockList = arr } = props;
    return (
        <ul className={styles['skeleton-form']}>
            {mockList.map((item, i) => (
                <li
                    className={classnames(styles['list-item'], item === 1 ? styles.w100 : styles.w50)}
                    key={i}
                />
            ))}
        </ul>);
}

export default SkeletonForm;
