import { useMemo } from 'react';
import { getValidateMap, validateForm } from './validate';

function useValidate(formFields, getColPrivateProps) {
    const validateMap = useMemo(() => {
        if (!formFields) return {};
        return getValidateMap(formFields, getColPrivateProps);
    }, [formFields, getColPrivateProps]);

    const validateData = useMemo(() => validateForm(validateMap, true), [validateMap]);

    return {
        validate: validateData,
    };
}

export default useValidate;
