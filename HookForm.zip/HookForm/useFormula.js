import { useCallback, useMemo, useRef } from 'react';
import { PureJs } from 'maycur-cloud';
import moment from 'moment';
import { getUserInfo } from '@u/redux';

const { Formula, getDependenceFieldsSort } = PureJs;
const isMoney = type => type === 'AmountInput';

const getValueFnMap = {
    // 之后可能还要依赖property去格式化值先改为高阶函数
    'TaxSelect': () => (val) => val ? +val.split('-')[0] : 0,
    'AmountInput': () => (val) => typeof val === 'number' ? val : val?.amount || 0,
};

const getDefaultUser = () => {
    const { userCode, name } = getUserInfo();
    return {
        userCode,
        userName: name,
    };
};

const getDefaultDate = ({ valueDefault, valueFormat }) => {
    if (valueDefault === 'NOW') return valueFormat === 'YYYY-MM' ? moment().startOf('month').valueOf() : Date.now();
};

const getDefaultSelect = ({ manualItems, valueDefault }) => {
    if (!manualItems?.length) return;
    return manualItems.find(({ code }) => code === valueDefault);
};

export const getFormulaInfo = (formFields, privateProps) => {
    const forMulaMap = {}, defaultValueMap = {}, formulaPoolKeys = [], _privateProps = privateProps || {}, valueFnMap = {};
    const allKeys = (formFields || []).map(({ identifier: k }) => k); // 校验无效字段
    (formFields || []).forEach(item => {
        const { identifier: _identifier, formulaDataRelations, property: { fillMethod } } = item;
        item.referFields = []; // 计算公式所依赖的字段
        if (['fromShared', 'formula'].includes(fillMethod) && formulaDataRelations?.length) {
            if (formulaDataRelations.some(({ type: _type, value: val }) => _type === 'variable' && !allKeys.includes(val))) return;
            forMulaMap[_identifier] = formulaDataRelations.map(({ value: relaValue }) => relaValue).join('');
            formulaDataRelations.forEach(({ type: _type, value: val }) => {
                if (_type === 'variable') {
                    item.referFields.push(val);
                    formulaPoolKeys.push(val);
                }
            });
        }
    });
    // 根据依赖字段进行排序
    const [firstSort, ...resSort] = getDependenceFieldsSort(formFields);

    const needFormatMoneyField = [];

    const newFirstSort = (firstSort || []).reduce((arr, { identifier: key, type, realType, property }) => {
        const _type = realType || type;
        if (formulaPoolKeys.includes(key) && _type in getValueFnMap) {
            valueFnMap[key] = getValueFnMap[_type](property);
        }
        if (property.fillMethod === 'formula') {
            return arr.concat({ key, type: _type });
        }

        let needDefault, valueDefault;
        if (key in _privateProps) {
            if (_privateProps[key].needDefault) needDefault = true;
            if (_privateProps[key].valueDefault) valueDefault = { valueDefault: _privateProps[key].valueDefault };
        }
        if (property.valueDefault && property.valueDefault !== 'NA') {
            needDefault = true;
        }
        if (needDefault) {
            let _v;
            if (_type === 'DateTimeInput') {
                const _date = getDefaultDate(property);
                if (_date) {
                    _v = property.selectionModule === 'PAIR' ? { timeRange: { startDate: _date, endDate: _date } } : { currentTime: _date };
                }
            }
            else if (_type === 'StaffInput') {
                _v = [getDefaultUser()];
            }
            else if (['OptionInput', 'PayConditionOptionInput', 'InvoiceOptionInput', 'QuotingTypeOption'].includes(_type)) {
                _v = getDefaultSelect({ ...property, ...valueDefault });
            }
            if (_v) {
                defaultValueMap[key] = _v;
                return arr.concat({ key, type: _type });
            }
        }
        if (isMoney(_type)) needFormatMoneyField.push(key);
        return arr;
    }, []);

    const newResSort = resSort.map(list => list.map(({ identifier: key, type, property, realType, referFields }) => {
        const _type = realType || type;
        if (formulaPoolKeys.includes(key) && _type in getValueFnMap) {
            valueFnMap[key] = getValueFnMap[_type](property);
        }
        return { key, type: _type, referFields };
    }));

    return {
        forMulaMap,
        formulaPoolKeys: [...new Set(formulaPoolKeys)],
        poolKeysMap: formulaPoolKeys.reduce((map, k) => {
            if (k in map) map[k]++;
            else map[k] = 1;
            return map;
        }, {}),
        sortedList: [newFirstSort, ...newResSort],
        defaultValueMap,
        valueFnMap,
        needFormatMoneyField,
    };
};

// 初始化数据
export const formDataInit = ({ formulaInfo, formData, parser, heighestCurrency }) => {
    const { defaultValueMap, needFormatMoneyField, forMulaMap, formulaPoolKeys, valueFnMap, sortedList: [firstSort, ...resSort] } = formulaInfo;
    const mapData = { __isInit: true };
    // 先把所有依赖项设值
    formulaPoolKeys.forEach(key => {
        const _val = key in valueFnMap ? valueFnMap[key](formData[key]) : formData[key];
        parser.updatePools({ [key]: _val });
    });

    needFormatMoneyField.forEach(key => {
        if (typeof formData[key] === 'number') mapData[key] = { amount: formData[key], currency: heighestCurrency || 'CNY' };
    });

    firstSort.forEach(({ key, type }) => {
        if (formData[key]) return; // 初始化有值则不处理
        const isAmount = isMoney(type);
        if (key in defaultValueMap) {
            mapData[key] = defaultValueMap[key];
        }
        else if (key in forMulaMap) {
            const { error, value } = parser.parse(forMulaMap[key]);
            if (!error) {
                const val = isAmount ? { amount: value, currency: heighestCurrency || 'CNY' } : value;
                mapData[key] = val;
                if (formulaPoolKeys.includes(key)) parser.updatePools({ [key]: value }); // 如果是作为其他字段的依赖，需要将初始值更新到formulaPool
            }
        }
    });

    resSort.forEach((list) => {
        list.forEach(({ key, type }) => {
            const isAmount = isMoney(type);
            if (key in forMulaMap) {
                const { error, value } = parser.parse(forMulaMap[key]);
                if (!error) {
                    const val = isAmount ? { amount: value, currency: heighestCurrency || 'CNY' } : value;
                    mapData[key] = val;
                    if (formulaPoolKeys.includes(key)) parser.updatePools({ [key]: value }); // 如果是作为其他字段的依赖，需要将初始值更新到formulaPool
                }
            }
        });
    });
    return mapData;
};

export default function useFormula(formFields, isInit, privateProps, heighestCurrency) {
    const formulaInfoRef = useRef({
        forMulaMap: {}, // 记录需要计算公式的
        formulaPoolKeys: [], // 计算公式数据池所需key
        sortedList: [], // 通过依赖项排序后的二维数组
        defaultValueMap: {}, // 有些组件需要默认值的
        valueFnMap: {}, // 获取特殊格式
    });

    const formulaParser = useRef();

    useMemo(() => {
        if (!isInit) return;
        formulaParser.current = new Formula();
        formulaInfoRef.current = getFormulaInfo(formFields, privateProps);
    }, [isInit]); // eslint-disable-line

    // 执行初始化计算公式
    const initFormulaData = useCallback((formData, needCalc) => {
        if (!needCalc || formData.__isInit) return {};
        return formDataInit({ formulaInfo: formulaInfoRef.current, formData, parser: formulaParser.current, heighestCurrency });
    }, [heighestCurrency]);

    // 单个字段改变触发计算公式
    const onFieldTriggerFormula = useCallback((key, getValues) => {
        const { forMulaMap, formulaPoolKeys, poolKeysMap, valueFnMap, sortedList: [firstSort, ...resSort] } = formulaInfoRef.current; // eslint-disable-line
        if (!formulaPoolKeys.includes(key)) return {};
        const res = {},
            parser = formulaParser.current;
        const poolValues = getValues(formulaPoolKeys);
        formulaPoolKeys.forEach((k, i) => {
            const val = poolValues[i];
            parser.updatePools({ [k]: k in valueFnMap ? valueFnMap[k](val) : val });
        });
        const needUpdateMap = { [key]: poolKeysMap[key] };
        for (const list of resSort) {
            if (!Object.keys(needUpdateMap).length) break;
            list.forEach(({ key: _key, type, referFields }) => {
                if (!(_key in forMulaMap)) return;
                let hasRefer = false;
                referFields.forEach(field => {
                    if (field in needUpdateMap) {
                        hasRefer = true;
                        const times = --needUpdateMap[field];
                        if (!times) delete needUpdateMap[field];
                    }
                });
                if (!hasRefer) return;
                const { error, value } = parser.parse(forMulaMap[_key]);
                if (!error) {
                    const val = isMoney(type) ? { amount: value, currency: heighestCurrency || 'CNY' } : value;
                    res[_key] = val;
                    if (formulaPoolKeys.includes(_key)) {
                        needUpdateMap[_key] = poolKeysMap[_key];
                        parser.updatePools({ [_key]: value });
                    }
                }
            });
        }
        return res;
    }, [heighestCurrency]);

    return { initFormulaData, onFieldTriggerFormula };
}
