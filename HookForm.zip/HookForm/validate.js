import { getCurMod } from '@u/redux';

export const DEFUALT_ERR_MSG = '该项为必填项';

export const getForms = (fields) => {
    if (!fields?.length) return {};
    const formMap = {
        FORM: [],
    };
    fields.forEach(field => {
        const { detailTableFields, identifier } = field;
        if (detailTableFields) {
            formMap[identifier] = detailTableFields;
            formMap.FORM.push(field);
        }
        else formMap.FORM.push(field);
    });
    return formMap;
};

export const getType = (type, property) => {
    return type === 'SharedFieldRefInput' ? property.reference.type : type;
};
export const getValidateType = (type) => {
    return type;
};
// 获取特殊组件的特殊属性
export const getTypeProps = (type, property) => {
    const realType = getType(type, property);
    const specialProps = {};
    // 因为不好区分对象与数组这边多传一个type，在共享字段选项的时候，也传数组
    if (['OptionInput'].includes(realType) && property.optionMode !== 'MULTI') {
        specialProps.singleToArr = true;
    }
    // 对账费用明细相关单据
    if ('StatementRelevantOrder' === realType) specialProps.labelKey = 'bizCode';
    return specialProps;
};

export const normalValidate = value => {
    if (Array.isArray(value)) return (value.length ? undefined : DEFUALT_ERR_MSG);
    return !!value ? undefined : DEFUALT_ERR_MSG;
};
export const maxLengthValidate = (maxLength) => (value) => value?.length < maxLength ? undefined : `最多只能输入${maxLength}个字`;

// 校验城市区间
const _validateCityPair = (value) => {
    const cityPair = value?.cityPair;
    if (!cityPair || !cityPair.departure || !cityPair.destination) return DEFUALT_ERR_MSG;
};

// 校验日期区间
const _validateDateRange = (value) => {
    const timeRange = value?.timeRange;
    if (!timeRange || !timeRange.startDate || !timeRange.endDate) return DEFUALT_ERR_MSG;
};

const validate = {
    // 城市组件校验
    CityInput: (property) => (value) => {
        const { selectionModule } = property;
        if (selectionModule === 'SINGLE') {
            return normalValidate(value?.location);
        }
        return _validateCityPair(value);
    },
    DateTimeInput: (property) => (value) => {
        const { selectionModule = 'SINGLE' } = property;
        if (selectionModule === 'SINGLE') {
            return normalValidate(value?.currentTime);
        }
        return _validateDateRange(value);
    },
    AmountInput: () => (value) => {
        const val = typeof value === 'number' ? value : value?.amount;
        if (val === 0 || !!val) return;
        return DEFUALT_ERR_MSG;
    },
    TableInput: ({ required }, tableRef) => async (value) => {
        if (!required && !value?.length) return;
        if (required && !value?.length) return DEFUALT_ERR_MSG;
        if (!tableRef.current) return;
        return await tableRef.current.trigger();
    },
    NumberInput: ({ zeroDisabled }) => (value) => {
        if (zeroDisabled && value === 0) return '不能为0';
        if (value === 0 || !!value) return;
        return DEFUALT_ERR_MSG;
    },
    AddressSelect: () => (value) => {
        if (!value?.key && !value?.code) return DEFUALT_ERR_MSG;
    },
    // 核销组件校验
    ReceivableWriteOffFrom: ({ required }, tableRef) => async () => {
        if (required && tableRef.current) {
            return await tableRef.current.trigger();
        }
        return;
    },
    // 部门组件
    DepartmentInput: (property) => (value) => {
        if (!value?.[0]?.code && property?.required) return DEFUALT_ERR_MSG;
    },
    // 预计开票类型
    InvoiceOptionInput: () => (value) => {
        if (!value) return DEFUALT_ERR_MSG;
        if (!value.code && !value.hasEctInvoice) return DEFUALT_ERR_MSG;
    },
    MultiValueInput: ({ maxLength }) => (value) => {
        if (value?.length && value.some(_ => _?.name?.length > maxLength)) {
            return `最多只能输入${maxLength}个字`;
        }
    },
    LegalEntityInput: ({ optionMode }) => (value) => {
        if (optionMode === 'MULTI') {
            if (!value?.length) return DEFUALT_ERR_MSG;
        }
        else if (!value?.name) return DEFUALT_ERR_MSG;
    },
};

export const getValidateMap = (formFields, getColPrivateProps) => {
    const curMod = getCurMod();
    const _map = {}; // 校验方法
    const weakMap = {}; // 弱校验方法
    const customArr = []; // C级组件的identifier
    formFields.forEach(({ property, identifier, source, type }) => {
        if (property && property.required && (!property.editLicense || property.editLicense.includes(curMod))) {
            if (source === 'CUSTOM_DEFINED') {
                customArr.push(identifier);
            }

            if (typeof property.validate === 'function') {
                _map[identifier] = [property.validate];
            }
            else { // 组件特有校验逻辑
                const key = `${getValidateType(getType(type, property))}`;
                if (key in validate) {
                    _map[identifier] = [validate[key](property)];
                }
                else _map[identifier] = [normalValidate];
            }
            // property其他校验逻辑
            if (property.maxLength) {
                _map[identifier].push(maxLengthValidate(property.maxLength));
            }
        }
        if (typeof getColPrivateProps === 'function') {
            const _props = getColPrivateProps(identifier);
            const customRule = _props?.customRule;
            const weakRule = _props?.weakRule;
            if (typeof customRule === 'function') {
                if (!_map[identifier]) _map[identifier] = [];
                _map[identifier].push((value, record) => customRule(value, record));
            }
            if (typeof weakRule === 'function') {
                if (!weakMap[identifier]) weakMap[identifier] = [];
                weakMap[identifier].push((value, record) => weakMap(value, record));
            }
        }
    });
    return {
        validate: _map,
        weakValidate: weakMap,
        customArr,
    };
};

/**
 *
 * @param {*} validateMap 通过 getValidateMap 获取
 * @param {boolean} isDetail 是否明细校验
 * @returns function
 */
export const validateForm = (validateMap, isDetail) => (value) => {
    const { validate: _validate, weakValidate } = validateMap;
    const keys = Object.keys(_validate || {});
    const weakKeys = Object.keys(weakValidate || {});
    if (!isDetail) {
        return keys.every(k => _validate[k].every(v => {
            const msg = v(value[k], value);
            if (msg) console.warn('FORM', k, v); // eslint-disable-line
            return !msg;
        }));
    }
    const len = value?.length;
    const arr = [];
    for (let i = 0; i < len; i++) {
        const item = value[i];
        if (item.__isSpecialRow) continue; // 特殊渲染行不校验
        const pass = keys.every(k => _validate[k].every(v => {
            const msg = v(item[k], item);
            if (msg) console.warn('DT', k, i, v); // eslint-disable-line
            return !msg;
        }));
        if (!pass) {
            return i + 1;
        }
        weakKeys.every(k => weakValidate[k].every(v => {
            const msg = v(item[k], item);
            if (msg) {
                console.warn('WDT', k, i, v); // eslint-disable-line
                arr.push({
                    index: i,
                    msg,
                });
            }
            return !msg;
        }));
    }
    return arr.length ? arr : -1;
};

export default validate;
