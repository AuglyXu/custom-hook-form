import { lazy } from 'react';

const filedMap = {
    MKInput: lazy(() => import('../HookField/MkInput')),
    MKNumberInput: lazy(() => import('../HookField/MkNumberInput')),
    MoneyInput: lazy(() => import('../HookField/MoneyInput')),
    MKDatePicker: lazy(() => import('../HookField/MkDatePicker')),
    MKDateRangePicker: lazy(() => import('../HookField/MkDateRangePicker')),
    LegalEntityPicker: lazy(() => import('../HookField/LegalEntityPicker')),
    SupplyInput: lazy(() => import('../HookField/LegalEntityPicker/SupplyInput')),
    MKTextArea: lazy(() => import('../HookField/MKTextArea')),
    SplitSpace: lazy(() => import('@c/SplitSpace')),
    AddressField: lazy(() => import('../HookField/AddressField')),
    DepartmentInput: lazy(() => import('../HookField/DepartmentInput')),
    StaffInput: lazy(() => import('../HookField/StaffInput')),
    RoleInput: lazy(() => import('../HookField/RoleInput')),
    MKSelect: lazy(() => import('../HookField/MKSelect')),
    EnterpriseInfoInput: lazy(() => import('../HookField/EnterpriseInfoInput')),
    ChargeType: lazy(() => import('../HookField/ChargeType')),
    TaxClassificationInput: lazy(() => import('../HookField/TaxClassificationInput')),
    CityPicker: lazy(() => import('../HookField/CityPicker')),
    CityPairPicker: lazy(() => import('../HookField/CityPairPicker')),
    OptionDataSource: lazy(() => import('../HookField/OptionDataSource')),
    DescText: lazy(() => import('../HookField/DescText')),
    MultiValueInput: lazy(() => import('../HookField/MultiValueInput')),
    ImageInput: lazy(() => import('../HookField/ImageInput')),
    BizCodeInput: lazy(() => import('../HookField/BizCodeInput')),
    AttachInput: lazy(() => import('../HookField/AttachInput')),
    MaterialCategoryInput: lazy(() => import('../HookField/MaterialCategoryInput')),
    ReceiptLink: lazy(() => import('../HookField/ReceiptLink')),
    AmountRatioInput: lazy(() => import('../HookField/AmountRatioInput')),
    WeighingPicker: lazy(() => import('../HookField/WeighingField')),
    InvoiceOptionInput: lazy(() => import('../HookField/InvoiceOptionInput')),
    RelatedInput: lazy(() => import('../HookField/RelatedField')),
    AccountPicker: lazy(() => import('../HookField/AccountPicker')),
    TreePickerField: lazy(() => import('../HookField/TreePickerField')),
    CustomInput: lazy(() => import('@c/CustomInput')),
    PositionInput: lazy(() => import('../HookField/PositionInput')),

    // 明细组件
    DetailsTable: lazy(() => import('../HookField/DetailsTableNew')),
    PurchaseScheduleForm: lazy(() => import('../HookField/PurchaseScheduleField')),
    StatementScheduleForm: lazy(() => import('../HookField/StatementScheduleForm')),
    InvoiceApplicationScheduleForm: lazy(() => import('../HookField/InvoiceApplicationScheduleForm')),
    AdvancePaymentApplicationScheduleForm: lazy(() => import('../HookField/AdvancePaymentApplicationScheduleForm')),
    MockQuotationSchedule: lazy(() => import('../HookField/MockQuotationSchedule')),
    PaymentBusinessItemForm: lazy(() => import('../HookField/PaymentBusinessItems')),
    RTRouteTable: lazy(() => import('../HookField/RTRouteTable')),
};

export default {
    SingleTextInput: filedMap['MKInput'],
    DateTimeInput: { SINGLE: filedMap['MKDatePicker'], MONTH: filedMap['MKDatePicker'], PAIR: filedMap['MKDateRangePicker'] },
    NumberInput: filedMap['MKNumberInput'], // 数字组件
    MultiTextInput: filedMap['MKTextArea'],
    AmountInput: filedMap['MoneyInput'],
    SplitSpace: filedMap['SplitSpace'],
    AddressSelect: filedMap['AddressField'],
    TableInput: filedMap['DetailsTable'],
    StaffInput: filedMap['StaffInput'],
    DepartmentInput: filedMap['DepartmentInput'],
    RoleInput: filedMap['RoleInput'], // 角色
    LegalEntityInput: { SINGLE: filedMap['LegalEntityPicker'], MULTI: filedMap['SupplyInput'] }, // 采购方/供应商
    PayConditionOptionInput: filedMap['MKSelect'],
    QuotingTypeOption: filedMap['MKSelect'],
    ChargeType: filedMap['ChargeType'], // 费用类型
    PurchaseScheduleForm: filedMap['PurchaseScheduleForm'], // 采购明细组件
    DeliveryScheduleForm: filedMap['PurchaseScheduleForm'], // 采购-送货明细组件
    ReceiptScheduleForm: filedMap['PurchaseScheduleForm'], // 采购-收货明细组件
    CZYOrderInput: filedMap['WeighingPicker'], // 采购-每刻云称组件
    QuotationScheduleForm: filedMap['PurchaseScheduleForm'], // 报价明细
    PaymentScheduleForm: filedMap['PurchaseScheduleForm'], // 应付明细
    InvoiceApplicationScheduleForm: filedMap['InvoiceApplicationScheduleForm'], // 开票明细组件
    AdvancePaymentApplicationScheduleForm: filedMap['AdvancePaymentApplicationScheduleForm'], // 提前付款申请明细
    OptionDataSource: filedMap['OptionDataSource'],
    DescText: filedMap['DescText'],
    OptionInput: { MANUAL: filedMap.MKSelect, DATA_SOURCE: filedMap.CustomInput, MULTI: filedMap.TreePickerField },
    EnterpriseInfoInput: filedMap['EnterpriseInfoInput'], // 采购/销售方信息
    StatementScheduleForm: filedMap['StatementScheduleForm'], // 对账明细
    TaxClassificationInput: filedMap['TaxClassificationInput'], // 税收分类选择组件
    CityInput: { SINGLE: filedMap['CityPicker'], PAIR: filedMap['CityPairPicker'] },
    StatementChargeScheduleForm: filedMap['DetailsTable'], // 费用明细
    StatementRelevantOrder: filedMap['OptionDataSource'], // 对账单费用明细的相关订单
    InvoiceOptionInput: filedMap['InvoiceOptionInput'], // 开票类型
    MultiValueInput: filedMap['MultiValueInput'], // 物料规格等可以添加多行的组件
    ImageInput: filedMap['ImageInput'], // 图片组件
    BizCodeInput: filedMap['BizCodeInput'], // 带自动获取bizCode按钮的Input组件
    AttachInput: filedMap['AttachInput'], // 附件
    MaterialCategoryInput: filedMap['MaterialCategoryInput'], // 物料类型
    FormAssociatedForm: filedMap['ReceiptLink'], // 单据关联
    InquiryScheduleForm: filedMap['PurchaseScheduleForm'], // 询价明细
    MockQuotationSchedule: filedMap['MockQuotationSchedule'], // 前端mock 报价明细组件，之后需要改造
    AccountInput: filedMap['AccountPicker'],
    AmountRatioInput: filedMap['AmountRatioInput'], // 金额比例组件
    PaymentRequestScheduleForm: filedMap['DetailsTable'], // 付款明细
    SourceFormList: filedMap['RelatedInput'], // 相关单据
    PaymentBusinessItemForm: filedMap['PaymentBusinessItemForm'], // 业务明细
    RTRouteInput: filedMap['RTRouteTable'],
    PositionInput: filedMap['PositionInput'],
};
