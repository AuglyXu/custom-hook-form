import MKInput from '../HookField/MkInput';
import MKNumberInput from '../HookField/MkNumberInput';
import MoneyInput from '../HookField/MoneyInput';
import MKDatePicker from '../HookField/MkDatePicker';
import MKDateRangePicker from '../HookField/MkDateRangePicker';
import LegalEntityPicker from '../HookField/LegalEntityPicker';
import SupplyInput from '../HookField/LegalEntityPicker/SupplyInput';
import MKTextArea from '../HookField/MKTextArea';
import SplitSpace from '@c/SplitSpace';
import AddressField from '../HookField/AddressField';
import DepartmentInput from '../HookField/DepartmentInput';
import StaffInput from '../HookField/StaffInput';
import RoleInput from '../HookField/RoleInput';
import MKSelect from '../HookField/MKSelect';
import EnterpriseInfoInput from '../HookField/EnterpriseInfoInput';
import OriginReceiptInfo from '../HookField/OriginReceiptInfo';
import ChargeType from '../HookField/ChargeType';
import TaxClassificationInput from '../HookField/TaxClassificationInput';
import AddressInfoField from '../HookField/AddressInfoField';
import CityPicker from '../HookField/CityPicker';
import CityPairPicker from '../HookField/CityPairPicker';
import OptionDataSource from '../HookField/OptionDataSource';
import DescText from '../HookField/DescText';
import MultiValueInput from '../HookField/MultiValueInput';
import ImageInput from '../HookField/ImageInput';
import BizCodeInput from '../HookField/BizCodeInput';
import AttachInput from '../HookField/AttachInput';
import MaterialCategoryInput from '../HookField/MaterialCategoryInput';
import ReceiptLink from '../HookField/ReceiptLink';
import AmountRatioInput from '../HookField/AmountRatioInput';
import WeighingPicker from '../HookField/WeighingField';
import InvoiceOptionInput from '../HookField/InvoiceOptionInput';
import RelatedInput from '../HookField/RelatedField';
import AccountPicker from '../HookField/AccountPicker';
import TreePickerField from '../HookField/TreePickerField';
import CustomInput from '@c/CustomInput';
import PositionInput from '../HookField/PositionInput';
import TaxSelectField from '../HookField/TaxSelect';
import ExchangeRateMoneyInput from '../HookField/ExchangeRateMoneyInput';
import WriteOffOrderTypeInput from '../HookField/WriteOffOrderTypeInput';
import TaxEquipment from '../HookField/TaxEquipment';

/** 明细组件 */
import RequirementScheduleForm from '../HookField/RequirementScheduleForm';
import DetailsTable from '../HookField/DetailsTableNew';
import PurchaseScheduleForm from '../HookField/PurchaseScheduleField';
import StatementScheduleForm from '../HookField/StatementScheduleForm';
import StatementScheduleFormAr from '../HookField/StatementScheduleForm';
import InvoiceApplicationScheduleForm from '../HookField/InvoiceApplicationScheduleForm';
import InvoiceApplicationScheduleFormAr from '../HookField/InvoiceApplicationScheduleFormAr';
import AdvancePaymentApplicationScheduleForm from '../HookField/AdvancePaymentApplicationScheduleForm';
import MockQuotationSchedule from '../HookField/MockQuotationSchedule';
import PaymentBusinessItemForm from '../HookField/PaymentBusinessItems';
import RTRouteTable from '../HookField/RTRouteTable';
import ReceivableWriteOffFrom from '../HookField/ReceivableWriteOffFrom';
import CollectionPlan from '../HookField/CollectionPlan'; // 收款计划
import EncasementScheduleForm from '../HookField/EncasementScheduleForm';
import StatementDifferenceItemFormAr from '../HookField/StatementDifferenceItemFormAr';

const fieldMap = {
    SingleTextInput: MKInput,
    DateTimeInput: { SINGLE: MKDatePicker, MONTH: MKDatePicker, PAIR: MKDateRangePicker },
    NumberInput: MKNumberInput, // 数字组件
    MultiTextInput: MKTextArea,
    AmountInput: MoneyInput,
    SplitSpace: SplitSpace,
    AddressSelect: AddressField,
    StaffInput: StaffInput,
    DepartmentInput: DepartmentInput,
    RoleInput: RoleInput, // 角色
    LegalEntityInput: { SINGLE: LegalEntityPicker, MULTI: SupplyInput }, // 采购方/供应商
    PayConditionOptionInput: MKSelect,
    QuotingTypeOption: MKSelect,
    GoodsOptionInput: MKSelect,
    ChargeType: ChargeType, // 费用类型
    RequirementScheduleForm: RequirementScheduleForm, // 采购需求明细表单
    PurchaseScheduleForm: PurchaseScheduleForm, // 采购明细组件
    DeliveryScheduleForm: PurchaseScheduleForm, // 采购-送货明细组件
    ReceiptScheduleForm: PurchaseScheduleForm, // 采购-收货明细组件
    CZYOrderInput: WeighingPicker, // 采购-每刻云称组件
    OptionDataSource: OptionDataSource,
    DescText: DescText,
    OptionInput: { MANUAL: MKSelect, DATA_SOURCE: CustomInput, MULTI: TreePickerField },
    EnterpriseInfoInput: EnterpriseInfoInput, // 采购/销售方信息
    TaxClassificationInput: TaxClassificationInput, // 税收分类选择组件
    CityInput: { SINGLE: CityPicker, PAIR: CityPairPicker },
    StatementRelevantOrder: OptionDataSource, // 对账单费用明细的相关订单
    InvoiceOptionInput: InvoiceOptionInput, // 开票类型
    MultiValueInput: MultiValueInput, // 物料规格等可以添加多行的组件
    ImageInput: ImageInput, // 图片组件
    BizCodeInput: BizCodeInput, // 带自动获取bizCode按钮的Input组件
    AttachInput: AttachInput, // 附件
    MaterialCategoryInput: MaterialCategoryInput, // 物料类型
    FormAssociatedForm: ReceiptLink, // 单据关联
    OriginReceiptInfo,
    AccountInput: AccountPicker,
    AmountRatioInput: AmountRatioInput, // 金额比例组件
    SourceFormList: RelatedInput, // 相关单据
    PositionInput: PositionInput,
    CollectionOptionInput: MKSelect,
    TaxSelect: TaxSelectField, // 税率选择组件
    AddressInfoField, // 收票信息
    ExchangeRateMoneyInput, // 核销金额
    TaxEquipmentInput: TaxEquipment, // 税控设备管理

    /** 明细组件 */
    RTRouteInput: RTRouteTable,
    StatementScheduleForm: StatementScheduleForm, // 对账明细
    QuotationScheduleForm: PurchaseScheduleForm, // 报价明细
    PaymentScheduleForm: PurchaseScheduleForm, // 应付明细
    InvoiceApplicationScheduleForm: InvoiceApplicationScheduleForm, // 开票明细组件
    AdvancePaymentApplicationScheduleForm: AdvancePaymentApplicationScheduleForm, // 提前付款申请明细
    StatementScheduleFormAr: StatementScheduleFormAr, //云销对账明细
    StatementDifferenceItemFormAr: StatementDifferenceItemFormAr, // 云销差异项
    StatementChargeScheduleForm: DetailsTable, // 费用明细
    InquiryScheduleForm: PurchaseScheduleForm, // 询价明细
    PaymentRequestScheduleForm: DetailsTable, // 付款明细
    PaymentBusinessItemForm: PaymentBusinessItemForm, // 业务明细
    RequisitionScheduleForm: PurchaseScheduleForm, // 请购明细
    MockQuotationSchedule: MockQuotationSchedule, // 前端mock 报价明细组件，之后需要改造
    WriteOffOrderTypeInput, // 核销单据类型
    InvoiceApplicationScheduleFormAr, // 云销开票明细
    ReceivableWriteOffFrom, // 收款核销组件
    TableInput: DetailsTable,
    ReceivablePlanScheduleFormAr: CollectionPlan, // 应收单-收款计划
    ReceivableBusinessScheduleFormAr: DetailsTable, // 应收单-业务明细
    ReceivableInvoiceScheduleFormAr: DetailsTable, // 应收单-发票明细
    CustomerStatementItemFormAr: DetailsTable,
    EncasementScheduleForm: EncasementScheduleForm, // 装箱明细
};

const getRealType = (type, property) => type === 'SharedFieldRefInput' ? property.reference.type : type;

export const getNode = (type, property) => {
    const realType = getRealType(type, property);
    const { isFieldHide, sourceMode, optionMode, selectionModule } = property;
    if (isFieldHide || !(realType in fieldMap)) return null;
    // 转换成具体的组件
    let Field = fieldMap[realType];
    // 处理两种特殊的情况
    if (['CityInput', 'DateTimeInput'].includes(realType)) {
        Field = Field[selectionModule || 'SINGLE'];
    }
    else if (['OptionInput'].includes(realType)) {
        if (sourceMode === 'DATA_SOURCE' && optionMode === 'MULTI') Field = Field.MULTI;
        else Field = Field[sourceMode];
    }
    else if (['LegalEntityInput'].includes(realType)) {
        Field = Field[optionMode || 'SINGLE'];
    }
    return Field;
};

export default fieldMap;
