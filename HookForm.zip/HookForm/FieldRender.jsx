import React, { memo, useMemo, useCallback, useRef } from 'react';
import { Controller } from 'react-hook-form';
import { Col } from 'maycur-antd';
import { getNode } from './FieldMap';
import FieldWrap from './FieldWrap';
import validateMap, { normalValidate, getType, getTypeProps, getValidateType } from './validate';
import { getCurMod } from '@u/redux';

const tableTypeArr = [
    'RequirementScheduleForm',
    'PurchaseScheduleForm',
    'DeliveryScheduleForm',
    'ReceiptScheduleForm',
    'StatementScheduleForm',
    'InvoiceApplicationScheduleForm',
    'InquiryScheduleForm',
    'QuotationScheduleForm',
    'AdvancePaymentApplicationScheduleForm',
    'StatementChargeScheduleForm',
    'PaymentRequestScheduleForm',
    'PaymentScheduleForm',
    'TableInput',
    'MockQuotationSchedule',
    'PaymentBusinessItemForm',
    'RTRouteInput',
    'RequisitionScheduleForm',
    'StatementScheduleFormAr',
    'ReceivableWriteOffFrom',
    'InvoiceApplicationScheduleFormAr',
    'ReceivablePlanScheduleFormAr',
    'ReceivableBusinessScheduleFormAr',
    'ReceivableInvoiceScheduleFormAr',
    'CustomerStatementItemFormAr',
    'EncasementScheduleForm',
    'StatementDifferenceItemFormAr',
];

// 组件底层使用了 MKSelect 组件，且需要特殊传参的类型
export const useMKSelectContainerTypeArr = [
    'LegalEntityInput',
    'TaxEquipmentInput',
];

const hideLabelArr = [...tableTypeArr, 'AccountInput', 'CZYOrderInput', 'FormAssociatedForm'];

function FieldRender(props) {
    const {
        field: { type: fieldType, property, identifier, detailTableFields },
        isInTable, // 是否在明细中
        control, // hook-form 使用
        fieldStyleCategory, // 部分组件需要 origin
        setWatch, // watch函数
        errMsg, // 错误提示
        publicProps, // 所有组件需要的props
        privateProps, // 根据identifier取私有属性
        onTrigger, // 当有表单元素的值发生改变会触发
        entry, // new表示新建
        customCalc, // 自定义计算
        getCustomProps, // 获取自定义属性
        getValues, // hook-form 提供，获取表单值
        getPopupContainer, // rc-trigger使用
        heighestCurrency, // 最高优先级币种
        outerStyle,
    } = props;
    const realType = useMemo(() => getType(fieldType, property), []); // eslint-disable-line
    const tableRef = useRef();
    const curMod = useMemo(() => getCurMod(), []);

    const validateType = useMemo(() => realType === 'ReceivableWriteOffFrom' ? getValidateType(realType) : tableTypeArr.includes(realType) ? 'TableInput' : getValidateType(realType), [realType]);

    const hideLabel = useMemo(() => {
        return isInTable || hideLabelArr.includes(realType);
    }, [realType, isInTable]);

    const getProps = useCallback(() => {
        const specialProps = {};
        if (tableTypeArr.includes(realType)) {
            specialProps.onTrigger = onTrigger;
            specialProps.identifier = identifier;
            specialProps.heighestCurrency = heighestCurrency;
            specialProps.customCalc = customCalc; // 用户自定义计算
            specialProps.detailTableFields = detailTableFields; // 只有明细组件有
            if (['TableInput'].includes(realType)) {
                specialProps.getValues = getValues;
            }
            if (['PurchaseScheduleForm', 'DeliveryScheduleForm', 'ReceiptScheduleForm', 'QuotationScheduleForm', 'PaymentScheduleForm', 'InquiryScheduleForm', 'RequisitionScheduleForm', 'StatementScheduleForm', 'StatementScheduleFormAr', 'StatementDifferenceItemFormAr'].includes(realType)) {
                specialProps.type = realType;
            }
        }
        if (realType === 'AmountInput') { // 金额组件需要带上币种
            specialProps.heighestCurrency = heighestCurrency;
        }
        if (realType === 'OriginReceiptInfo') { // 原开票组件需要监听发票类型, 并根据发票类型判断是否需要税控设备
            specialProps.fetchFormData = getValues;
        }
        if (['DescText'].includes(realType)) { // 需要全局数据的组件
            specialProps.getValues = getValues;
        }
        let customProps;
        if (typeof getCustomProps === 'function') {
            customProps = getCustomProps({ type: realType, property, identifier });
        }
        if (realType === 'PayConditionOptionInput') {
            const _options = [
                { name: '到票后付款', code: 'INVOICE_RECEIVED' },
                { name: '开票后付款', code: 'INVOICED' },
                { name: '收货后付款', code: 'RECEIPTED' },
                { name: '送货后付款', code: 'DELIVERED' },
            ];
            const availableValues = property.availableValues;
            if (Array.isArray(availableValues)) {
                specialProps.manualItems = _options.filter(({ code }) => availableValues.includes(code));
            }
        }
        // 获取组件相关特殊属性
        Object.assign(specialProps, getTypeProps(realType, property));

        return {
            entry, // 新建为new，编辑为edit
            readOnly: ('editLicense' in property && !(property.editLicense || []).includes(curMod)) ? true : property.isFieldReadOnly,
            fieldStyleCategory, // 有些组件需要的样式类型（如Input在明细中显示 origin 模式）
            setWatch, // 监听函数
            isInTable, // 是否在明细中
            ...specialProps, // 特殊属性
            ...publicProps, // 公共属性
            ...property, // 表单配置里面的属性
            ...privateProps, // 私有属性
            ...customProps, // 用户自定义属性
            getPopupContainer: useMKSelectContainerTypeArr.includes(realType) ? getPopupContainer : undefined,
        };
    }, [publicProps, property, privateProps, onTrigger]); // eslint-disable-line

    const getRules = useCallback(() => {
        const { maxLength, maxSelectLength, required } = property;
        const rules = {};
        if (maxLength && !['AttachInput', 'InvoiceInput', 'InvoiceTable', 'ImageInput', 'MultiValueInput'].includes(realType)) {
            rules.maxLength = {
                value: maxLength,
                message: `最多只能输入${maxLength}个字`,
            };
        }
        const ruleArr = [];
        if (['TableInput', 'ReceivableWriteOffFrom', 'MultiValueInput'].includes(validateType)) {
            ruleArr.push(validateMap[validateType](property, tableRef));
        }
        else if (required) {
            if (validateType in validateMap) {
                ruleArr.push(validateMap[validateType](property));
            }
            else ruleArr.push(normalValidate);
        }
        if (maxSelectLength) {
            ruleArr.push((val) => {
                if (val?.length > maxSelectLength) {
                    return `选择不能超过${maxSelectLength}个`;
                }
            });
        }
        if (privateProps?.customRule) {
            ruleArr.push(privateProps.customRule);
        }
        if (privateProps?.weakRule) {
            ruleArr.push(privateProps.weakRule);
        }
        if (ruleArr.length) {
            rules.validate = (val) => {
                for (const fn of ruleArr) {
                    const msg = fn(val);
                    if (msg) return msg;
                }
            };
        }

        return rules;
    }, [property, realType, validateType, privateProps]);

    const renderNode = useCallback(() => {
        const { label, required } = property;
        const Field = getNode(realType, property);
        if (!Field) return null;

        if (realType === 'SplitSpace') { // 分割条
            return <Col span={24}><Field style={{ margin: '0 12px 10px' }} /></Col>;
        }

        // 这个先放这里看render次数
        // console.log('renderNode', identifier);

        return (
            <Controller
                control={control}
                name={identifier}
                render={({ field }) => {
                    const { onChange, onBlur, value, ref } = field;
                    /* 这里明细的dataSource改变会强制render 这里的优化暂时没用，后续换其他Table组件可以考虑 */
                    // const changeFn = tableTypeArr.includes(realType) ?
                    //     onChange : (...args) => {
                    //         onChange(...args);
                    //         onTrigger(
                    //             {
                    //                 key: identifier,
                    //                 value: args[0],
                    //                 oldValue: value,
                    //             }
                    //         );
                    //     };
                    let _ref;
                    if (tableTypeArr.includes(realType)) {
                        _ref = (elm) => {
                            ref(elm);
                            tableRef.current = elm;
                        };
                    }
                    else _ref = ref;
                    return (
                        <FieldWrap
                            errMsg={errMsg}
                            hideLabel={hideLabel}
                            isInTable={isInTable}
                            label={label}
                            outerStyle={outerStyle || {}}
                            required={required}
                        >
                            <Field
                                onBlur={onBlur}
                                // onChange={changeFn}
                                /** onChange
                                 * @param {object} val 更改后的值
                                 * @param {boolean} needFormTrigger 是否触发表单校验
                                 * @param {boolean} needTrigger 是否触发表单联动、计算公式等逻辑
                                 */
                                onChange={(val, needFormTrigger, needTrigger = true) => {
                                    onChange(val);
                                    needTrigger && onTrigger(
                                        {
                                            key: identifier,
                                            value: val,
                                            oldValue: value,
                                            needFormTrigger, // 需要触发表单校验
                                        }
                                    );
                                }}
                                ref={_ref}
                                value={value}
                                {...getProps()}
                            />
                        </FieldWrap>
                    );
                }}
                rules={getRules()}
            />);
    }, [property, realType, control, identifier, getRules, errMsg, hideLabel, isInTable, outerStyle, getProps, onTrigger]);

    const Node = useMemo(() => {
        const node = renderNode();
        if (!node) return null;
        return isInTable ?
            node :
            <Col span={property.webSize === 0.5 ? 12 : 24}>
                {node}
            </Col>;


    }, [property, renderNode, isInTable]);

    return Node;
}

export default memo(FieldRender);
