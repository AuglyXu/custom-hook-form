import React, { useMemo } from 'react';
import { getNode } from './FieldMap';
import { getTypeProps } from './validate';

function ViewFieldRender(props) {
    const { type, property, fieldStyleCategory, value, showPlaceholder, isInTable, needPopover } = props;

    const Field = useMemo(() => getNode(type, property), []); // eslint-disable-line
    const specialProps = getTypeProps(type, property);

    if (!Field) return null;
    return (
        <Field
            {...property}
            {...specialProps}
            fieldStyleCategory={fieldStyleCategory}
            isInTable={isInTable}
            needPopover={needPopover}
            readOnly
            showPlaceholder={showPlaceholder}
            value={value}
        />
    );
}

export default ViewFieldRender;
