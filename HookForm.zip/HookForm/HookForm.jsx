import React, { Suspense, useMemo, memo, forwardRef, useImperativeHandle, useCallback, useRef } from 'react';
import FieldRender from './FieldRender';
import SkeletonForm from './SkeletonForm';
import { useForm, FormProvider } from 'react-hook-form';
import useFormula from './useFormula';

const getViewType = (type) => {
    if (['AddressInfoField', 'OriginReceiptInfo'].includes(type)) return 'type1';
    if (['EnterpriseInfoInput'].includes(type)) return 'type2';
    if (['ImageInput', 'AttachInput'].includes(type)) return 'type3';
    if (['AccountInput'].includes(type)) return 'type4';
    return 'normal';
};

const Form = forwardRef(function (props, ref) {
    const { formFields, privateProps, publicProps, defaultFormData, customCalc, onFieldTriggerFormula, getCustomProps, heighestCurrency, useMuti } = props;
    const {
        control,
        formState: { errors },
        trigger,
        getValues,
        setValue,
        handleSubmit,
        reset,
    } = useForm({ defaultValues: defaultFormData });

    const watchMapRef = useRef({});
    const validateResRef = useRef({});

    const getPopupContainer = useMemo(() => {
        if (useMuti) return () => document.querySelector('.muti-details');
    }, [useMuti]);

    const entry = useMemo(() => /^MOCK_/.test(defaultFormData.code || 'MOCK_') ? 'new' : 'edit', []); // eslint-disable-line

    const onTrigger = useCallback(({ key, value, oldValue, needFormTrigger = true, needSetValue }) => {
        let customRes;
        if (typeof customCalc === 'function') {
            customRes = customCalc({
                key,
                value,
                formData: getValues(),
            });
        }
        const res = { ...onFieldTriggerFormula(key, getValues), ...customRes };
        Object.keys(res).forEach(k => {
            setValue(k, res[k]);
        });
        if (needSetValue) setValue(key, value);
        const watchMap = watchMapRef.current;
        if (key in watchMap) {
            watchMap[key].forEach(fn => {
                fn(value, oldValue);
            });
        }
        if (needFormTrigger) trigger(key);
    }, [trigger, onFieldTriggerFormula, setValue, customCalc, getValues]);

    const setWatch = useCallback((key, fn) => {
        const watchMap = watchMapRef.current;
        if (!(key in watchMap)) {
            watchMap[key] = [];
        }
        watchMap[key].push(fn);
    }, []);

    const needWhiteBlockIndex = useMemo(() => {
        if (!formFields?.length) return [];
        const res = [];
        let leftType = null;
        formFields.forEach(({ type, property }, i) => {
            if (property && property.isFieldHide) return;
            if (!property || property.webSize === 1) return leftType = null;
            const _type = getViewType(type);
            if (leftType) {
                if (leftType !== _type) {
                    res.push(i);
                    leftType = _type;
                }
                else leftType = null;
            }
            else leftType = _type;
        });
        return res;
    }, [formFields]);

    const onSubmit = useMemo(() => {
        return handleSubmit((data) => {
            validateResRef.current.isError = false;
            validateResRef.current.res = data;
        }, (err) => {
            validateResRef.current.isError = true;
            validateResRef.current.res = err;
        });
    }, [handleSubmit]);

    useImperativeHandle(ref, () => ({
        trigger: async () => {
            await onSubmit();
            const { res, isError } = validateResRef.current;
            if (isError) {
                return Promise.reject(res);
            }
            return res;
        },
        getValues,
        reset,
    }), [getValues, reset, onSubmit]);

    return formFields ?
        formFields.map((field, i) => {
            const { identifier } = field;
            return (
                <React.Fragment key={identifier}>
                    {needWhiteBlockIndex.includes(i) &&
                        <div className="ant-col-12 ant-col-field"></div>
                    }
                    <FieldRender
                        control={control}
                        entry={entry}
                        errMsg={errors[identifier]?.message}
                        field={field}
                        getCustomProps={getCustomProps}
                        getPopupContainer={getPopupContainer}
                        getValues={getValues}
                        heighestCurrency={heighestCurrency}
                        onTrigger={onTrigger}
                        privateProps={privateProps?.[identifier]}
                        publicProps={publicProps}
                        setWatch={setWatch}
                    />
                </React.Fragment>
            );
        }) : null;
});

function HookForm(props, ref) {
    const { isInit, formData, formFields, privateProps, getCustomProps, heighestCurrency, ...otherProps } = props;

    const { initFormulaData, onFieldTriggerFormula } = useFormula(formFields, isInit, privateProps, heighestCurrency);

    const defaultFormData = useMemo(() => {
        if (isInit) {
            const data = { ...formData, ...formData?.customObject };
            const changeData = initFormulaData(data, /^MOCK_/.test(data.code || 'MOCK_'));
            return { ...data, ...changeData };
        }
    }, [isInit]); // eslint-disable-line

    return (
        <div className="hook-form">
            <Suspense fallback={<SkeletonForm />}>
                {isInit ?
                    <FormProvider getCustomProps={getCustomProps}>
                        <Form
                            {...otherProps}
                            defaultFormData={defaultFormData}
                            formFields={formFields}
                            getCustomProps={getCustomProps}
                            heighestCurrency={heighestCurrency}
                            onFieldTriggerFormula={onFieldTriggerFormula}
                            privateProps={privateProps}
                            ref={ref}
                        />
                    </FormProvider> :
                    <SkeletonForm />
                }
            </Suspense>
        </div>
    );
}

export default memo(forwardRef(HookForm));
