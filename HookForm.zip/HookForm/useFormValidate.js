import { useCallback, useMemo } from 'react';
import { getForms, getValidateMap, validateForm } from './validate';

function useFormValidate(formFields, getColPrivatePropsMap) {

    const validateMap = useMemo(() => {
        if (!formFields) return {};
        const formMap = getForms(formFields);
        const _map = {};
        Object.keys(formMap).forEach(k => {
            _map[k] = getValidateMap(formMap[k], getColPrivatePropsMap?.[k]);
        });
        return _map;
    }, [formFields, getColPrivatePropsMap]);

    const validateData = useCallback((formData) => {
        for (const key in validateMap) {
            if (key === 'FORM') {
                const res = validateForm(validateMap[key])(formData);
                if (!res) return false;
            }
            else {
                const res = validateForm(validateMap[key], true)(formData[key]);
                if (res !== -1) return false;
            }
        }
        return true;
    }, [validateMap]);

    return {
        validate: validateData,
    };
}

export default useFormValidate;
