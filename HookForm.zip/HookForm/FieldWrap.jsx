import React, { useMemo, memo } from 'react';
import classnames from 'classnames';
import styles from './Field.module.less';

function FieldWrap(props) {
    const { children, errMsg, label, required, hideLabel, isInTable, outerStyle } = props;

    const className = useMemo(() => {
        return classnames(styles['field-wrap'], !!errMsg ? 'has-error' : 'has-success', { [styles.required]: required && !hideLabel, [styles['in-table']]: isInTable });
    }, [errMsg, required, hideLabel, isInTable]);

    return (
        <div className={className}
            style={{ ...outerStyle }}
        >
            {label && !hideLabel &&
                <div className={styles['field-label']}>{label}</div>
            }
            <div className={styles['item-children']}>{children}</div>
            {errMsg &&
                <div className={styles['err-msg']}>{errMsg}</div>
            }
        </div>);
}

export default memo(FieldWrap);
