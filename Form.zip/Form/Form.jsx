import React, { useMemo, useRef, forwardRef, useImperativeHandle } from 'react';
import { useForm } from 'react-hook-form';
import FormContext from './context';

function Form(props, ref) {
    const {
        defaultFormData,
        children,
        onChange,
    } = props;

    const {
        control,
        formState: { errors },
        trigger,
        getValues,
        setValue,
        handleSubmit,
        reset,
        unregister,
    } = useForm({ defaultValues: defaultFormData });
    const validateResRef = useRef({});

    const contextValue = useMemo(() => ({
        errors,
        control,
        trigger,
        onChange,
    }), [control, errors, onChange, trigger]);

    const onSubmit = useMemo(() => {
        return handleSubmit((data) => {
            validateResRef.current.isError = false;
            validateResRef.current.res = data;
        }, (err) => {
            validateResRef.current.isError = true;
            validateResRef.current.res = err;
        });
    }, [handleSubmit]);

    useImperativeHandle(ref, () => ({
        trigger: async () => {
            await onSubmit();
            const { res, isError } = validateResRef.current;
            if (isError) {
                return Promise.reject(res);
            }
            return res;
        },
        getValues,
        setValue,
        reset,
        unregister,
    }), [getValues, setValue, reset, unregister, onSubmit]);

    return (
        <FormContext.Provider value={contextValue}>
            {children}
        </FormContext.Provider>);
}

export default forwardRef(Form);
