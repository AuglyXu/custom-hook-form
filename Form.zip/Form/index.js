import Form from './Form';
import Item from './Item';

Form.Item = Item;

export default Form;
